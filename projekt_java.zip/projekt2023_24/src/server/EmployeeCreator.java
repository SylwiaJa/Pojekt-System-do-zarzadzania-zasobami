package server;

public class EmployeeCreator {
    public Employee create(String login){


        return null;
    }
}
