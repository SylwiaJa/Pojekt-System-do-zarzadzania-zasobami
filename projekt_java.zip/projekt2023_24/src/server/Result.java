package server;

public class Result {
    private int quantityOK;
    private int quantityNOK;
    private String information;

    public Result(int quantityOK, int quantityNOK, String information) {
        this.quantityOK = quantityOK;
        this.quantityNOK = quantityNOK;
        this.information = information;
    }
}
