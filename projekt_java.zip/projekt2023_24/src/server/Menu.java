package server;

public class Menu {
    public void displayLoginMenu(){};
    public void login(String login, String password){};
    public void displayMenuAfterLogin(Employee employee){};
    public void loginErrorInfo(){};
    public void logOut(Employee employee){};
    public void logOutInfo(){};
    public void displayMenuWorker(Employee employee){};
    public void displayMenuLeader(Employee employee){};
    public void displayMenuManager(Employee employee){};
    public void displayMenuAdmin(Employee employee){};
    public void updateListOfTask(){};
}
